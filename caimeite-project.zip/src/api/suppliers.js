import request from './request'

export function getSupplierList(params) {
  return request.get('/suppliers', { params })
}

export function getSupplier(id) {
  return request.get(`/suppliers/${id}`)
}

export function createSupplier(data) {
  return request.post('/suppliers', data)
}

export function updateSupplier(id, data) {
  return request.put(`/suppliers/${id}`, data)
}

export function deleteSupplier(id) {
  return request.delete(`/suppliers/${id}`)
}

export function batchDeleteSuppliers(ids) {
  return request.post('/suppliers/batch-delete', { ids })
}

export const addSupplier = createSupplier
